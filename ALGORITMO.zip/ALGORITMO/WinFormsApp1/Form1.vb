﻿Public Class Form1
    Private Sub suma_Click(sender As Object, e As EventArgs) Handles suma.Click
        If num1.Text = "" Or num2.Text = "" Then
            MsgBox("INGRESA UN VALOR")
        Else
            resultado.Text = Val(num1.Text) + (num2.Text)
        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub resta_Click(sender As Object, e As EventArgs) Handles resta.Click
        If num1.Text = "" Or num2.Text = "" Then
            MsgBox("INGRESA UN VALOR")
        Else
            resultado.Text = Val(num1.Text) - (num2.Text)
        End If

    End Sub

    Private Sub divicion_Click(sender As Object, e As EventArgs) Handles divicion.Click
        If num1.Text = "" Or num2.Text = "" Then
            MsgBox("INGRESA UN VALOR")
        Else
            resultado.Text = Val(num1.Text) / (num2.Text)
        End If

    End Sub

    Private Sub multiplicacion_Click(sender As Object, e As EventArgs) Handles multiplicacion.Click
        If num1.Text = "" Or num2.Text = "" Then
            MsgBox("INGRESA UN VALOR")
        Else
            resultado.Text = Val(num1.Text) * (num2.Text)
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        num1.Clear()
        num2.Clear()
        If num1.Text = "" Then resultado.Text = ""
        Me.num1.Focus()

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
        Dim a As String
        Dim b As String
        Dim c As String
        a = num1.Text
        b = num2.Text
        c = resultado.Text

    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub porcentaje_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)



    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs) Handles Panel3.Paint



    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If d1.Text = "" Then d1.Text = "0"
        If d2.Text = "" Then d2.Text = "0"
        If d3.Text = "" Then d3.Text = "0"
        If d4.Text = "" Then d4.Text = "0"
        If d5.Text = "" Then d5.Text = "0"
        If d6.Text = "" Then d6.Text = "0"
        dt.Text = (sueldo.Text - d1.Text - d2.Text - d3.Text - d4.Text - d5.Text - d6.Text)
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Cantidad1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click_2(sender As Object, e As EventArgs) Handles Button2.Click
        sueldo.Clear()
        d1.Clear()
        d2.Clear()
        d3.Clear()
        d4.Clear()
        d5.Clear()
        d6.Clear()
        dt.Clear()
    End Sub
End Class
