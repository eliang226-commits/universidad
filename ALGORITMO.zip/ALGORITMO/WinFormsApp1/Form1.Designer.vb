﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.num1 = New System.Windows.Forms.TextBox()
        Me.num2 = New System.Windows.Forms.TextBox()
        Me.suma = New System.Windows.Forms.Button()
        Me.resultado = New System.Windows.Forms.Label()
        Me.resta = New System.Windows.Forms.Button()
        Me.multiplicacion = New System.Windows.Forms.Button()
        Me.divicion = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.dt = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.d6 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.d5 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.d3 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.d4 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.d2 = New System.Windows.Forms.TextBox()
        Me.d1 = New System.Windows.Forms.TextBox()
        Me.sueldo = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'num1
        '
        Me.num1.Location = New System.Drawing.Point(51, 20)
        Me.num1.Name = "num1"
        Me.num1.Size = New System.Drawing.Size(78, 23)
        Me.num1.TabIndex = 0
        '
        'num2
        '
        Me.num2.Location = New System.Drawing.Point(51, 49)
        Me.num2.Name = "num2"
        Me.num2.Size = New System.Drawing.Size(78, 23)
        Me.num2.TabIndex = 1
        '
        'suma
        '
        Me.suma.Location = New System.Drawing.Point(5, 89)
        Me.suma.Name = "suma"
        Me.suma.Size = New System.Drawing.Size(75, 39)
        Me.suma.TabIndex = 2
        Me.suma.Text = "SUMA"
        Me.suma.UseVisualStyleBackColor = True
        '
        'resultado
        '
        Me.resultado.AutoSize = True
        Me.resultado.Font = New System.Drawing.Font("Arial Rounded MT Bold", 24.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.resultado.Location = New System.Drawing.Point(17, 266)
        Me.resultado.Name = "resultado"
        Me.resultado.Size = New System.Drawing.Size(27, 37)
        Me.resultado.TabIndex = 3
        Me.resultado.Text = "."
        '
        'resta
        '
        Me.resta.Location = New System.Drawing.Point(86, 89)
        Me.resta.Name = "resta"
        Me.resta.Size = New System.Drawing.Size(75, 39)
        Me.resta.TabIndex = 4
        Me.resta.Text = "RESTA"
        Me.resta.UseVisualStyleBackColor = True
        '
        'multiplicacion
        '
        Me.multiplicacion.Location = New System.Drawing.Point(33, 129)
        Me.multiplicacion.Name = "multiplicacion"
        Me.multiplicacion.Size = New System.Drawing.Size(113, 39)
        Me.multiplicacion.TabIndex = 5
        Me.multiplicacion.Text = "MULTIPLICACION"
        Me.multiplicacion.UseVisualStyleBackColor = True
        '
        'divicion
        '
        Me.divicion.Location = New System.Drawing.Point(5, 169)
        Me.divicion.Name = "divicion"
        Me.divicion.Size = New System.Drawing.Size(72, 39)
        Me.divicion.TabIndex = 6
        Me.divicion.Text = "DIVICION"
        Me.divicion.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Silver
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.num1)
        Me.Panel1.Controls.Add(Me.num2)
        Me.Panel1.Controls.Add(Me.divicion)
        Me.Panel1.Controls.Add(Me.suma)
        Me.Panel1.Controls.Add(Me.multiplicacion)
        Me.Panel1.Controls.Add(Me.resultado)
        Me.Panel1.Controls.Add(Me.resta)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(206, 358)
        Me.Panel1.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(5, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 17)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "NUM2"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(5, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 17)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "NUM1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(86, 169)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 39)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "BORRAR"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Silver
        Me.Panel3.Controls.Add(Me.Button2)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.dt)
        Me.Panel3.Controls.Add(Me.Button3)
        Me.Panel3.Controls.Add(Me.d6)
        Me.Panel3.Controls.Add(Me.Label14)
        Me.Panel3.Controls.Add(Me.d5)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.d3)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.d4)
        Me.Panel3.Controls.Add(Me.Label10)
        Me.Panel3.Controls.Add(Me.d2)
        Me.Panel3.Controls.Add(Me.d1)
        Me.Panel3.Controls.Add(Me.sueldo)
        Me.Panel3.Controls.Add(Me.Label11)
        Me.Panel3.Controls.Add(Me.Label12)
        Me.Panel3.Controls.Add(Me.Label13)
        Me.Panel3.Location = New System.Drawing.Point(304, 12)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(347, 358)
        Me.Panel3.TabIndex = 10
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(231, 63)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(78, 17)
        Me.Label15.TabIndex = 39
        Me.Label15.Text = "RESULTADO"
        '
        'dt
        '
        Me.dt.Location = New System.Drawing.Point(212, 81)
        Me.dt.Name = "dt"
        Me.dt.Size = New System.Drawing.Size(118, 23)
        Me.dt.TabIndex = 38
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(143, 8)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(84, 39)
        Me.Button3.TabIndex = 37
        Me.Button3.Text = "RESULTADO"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'd6
        '
        Me.d6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.d6.Location = New System.Drawing.Point(28, 324)
        Me.d6.Name = "d6"
        Me.d6.Size = New System.Drawing.Size(100, 25)
        Me.d6.TabIndex = 36
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(28, 304)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(49, 17)
        Me.Label14.TabIndex = 35
        Me.Label14.Text = "OTROS"
        '
        'd5
        '
        Me.d5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.d5.Location = New System.Drawing.Point(28, 276)
        Me.d5.Name = "d5"
        Me.d5.Size = New System.Drawing.Size(100, 25)
        Me.d5.TabIndex = 34
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(28, 256)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(63, 17)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "AHORRO"
        '
        'd3
        '
        Me.d3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.d3.Location = New System.Drawing.Point(28, 231)
        Me.d3.Name = "d3"
        Me.d3.Size = New System.Drawing.Size(100, 25)
        Me.d3.TabIndex = 32
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(28, 211)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 17)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "TELEFONO"
        '
        'd4
        '
        Me.d4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.d4.Location = New System.Drawing.Point(28, 183)
        Me.d4.Name = "d4"
        Me.d4.Size = New System.Drawing.Size(100, 25)
        Me.d4.TabIndex = 30
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(28, 157)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(60, 17)
        Me.Label10.TabIndex = 29
        Me.Label10.Text = "COMIDA"
        '
        'd2
        '
        Me.d2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.d2.Location = New System.Drawing.Point(25, 129)
        Me.d2.Name = "d2"
        Me.d2.Size = New System.Drawing.Size(100, 25)
        Me.d2.TabIndex = 28
        '
        'd1
        '
        Me.d1.Location = New System.Drawing.Point(25, 84)
        Me.d1.Name = "d1"
        Me.d1.Size = New System.Drawing.Size(100, 23)
        Me.d1.TabIndex = 27
        '
        'sueldo
        '
        Me.sueldo.Location = New System.Drawing.Point(25, 38)
        Me.sueldo.Name = "sueldo"
        Me.sueldo.Size = New System.Drawing.Size(100, 23)
        Me.sueldo.TabIndex = 26
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(25, 111)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(94, 17)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "ELECTRICIDAD"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(28, 64)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(100, 17)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "PAGO DE CASA"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(25, 18)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(96, 17)
        Me.Label13.TabIndex = 23
        Me.Label13.Text = "SUELDO TOTAL"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(233, 8)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(84, 39)
        Me.Button2.TabIndex = 40
        Me.Button2.Text = "BORRAR"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(665, 386)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "SUMA"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents num1 As TextBox
    Friend WithEvents num2 As TextBox
    Friend WithEvents suma As Button
    Friend WithEvents resultado As Label
    Friend WithEvents resta As Button
    Friend WithEvents multiplicacion As Button
    Friend WithEvents divicion As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents d6 As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents d5 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents d3 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents d4 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents d2 As TextBox
    Friend WithEvents d1 As TextBox
    Friend WithEvents sueldo As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents dt As TextBox
    Friend WithEvents Button2 As Button
End Class
