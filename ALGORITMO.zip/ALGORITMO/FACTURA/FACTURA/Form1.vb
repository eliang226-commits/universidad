﻿Public Class Form1
    Dim b As Integer
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.Text = "Mentas" Then TextBox1.Text = "2"
        TextBox2.Text = "500"
        TextBox5.Text = "1"
        If ComboBox1.Text = "3 Leche" Then TextBox1.Text = "75"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Brownies" Then TextBox1.Text = "15"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Cupcakes" Then TextBox1.Text = "25"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Donas" Then TextBox1.Text = "25"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Donas con azucal" Then TextBox1.Text = "20"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Chiches" Then TextBox1.Text = "5"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Piruletas" Then TextBox1.Text = "15"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Cake pop" Then TextBox1.Text = "20"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Galleta Glaseadas" Then TextBox1.Text = "15"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Oreos" Then TextBox1.Text = "10"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Dinos" Then TextBox1.Text = "10"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Chokis" Then TextBox1.Text = "30"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Chocoreo" Then TextBox1.Text = "100"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Malteada" Then TextBox1.Text = "75"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Nutesweet" Then TextBox1.Text = "300"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Malteada" Then TextBox1.Text = "75"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Jugo peti" Then TextBox1.Text = "15"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Jugo Santal" Then TextBox1.Text = "20"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Yogurt" Then TextBox1.Text = "25"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Pilones" Then TextBox1.Text = "5"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Bizcocho Diabetico(Pedazos)" Then TextBox1.Text = "10"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Bizcocho Diabetico Entero" Then TextBox1.Text = "250"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Granola" Then TextBox1.Text = "35"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Conflaces con Azucar" Then TextBox1.Text = "10"
        TextBox2.Text = "100"
        If ComboBox1.Text = "Conflaces sin Azucar" Then TextBox1.Text = "15"
        TextBox2.Text = "100"

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox3.Text = ComboBox1.Text
        TextBox4.Text = TextBox1.Text
        Label11.Text = TextBox2.Text - TextBox5.Text
        TextBox6.Text = TextBox4.Text * TextBox5.Text
        b = b + TextBox6.Text

        If Label11.Text = "0" Then MsgBox("Error Cantidad Insuficiente")
        DataGridView1.Rows.Add(TextBox3.Text, TextBox4.Text, TextBox5.Text, TextBox6.Text)

        TextBox7.Text = DataGridView1.Item(3, 0).Value + TextBox7.Text = DataGridView1.Item(3, 1).Value
        TextBox7.Text = b
        TextBox8.Text = b * 18 / 100
        TextBox9.Text = b + TextBox8.Text











    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        DataGridView1.Rows.Clear()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        Label11.Text = "."

    End Sub



    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)





    End Sub
End Class
